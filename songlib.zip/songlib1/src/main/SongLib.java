/*
 * authors: Ziyun Zhi, Junren Zhu
 */

package main;

import javafx.application.Application;
import ui.App;

public class SongLib {
    public static void main(String[] args) {
        Application.launch(App.class);
    }
}
